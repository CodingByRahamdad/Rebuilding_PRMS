import { z } from 'zod';

const emergencyContactSchema = z.object({
  name: z.string().optional().default('Next of Kin'),
  relationship: z.string().optional().default('Family'),
  relation: z.string().optional(),
  phone: z.string().optional().default(''),
}).passthrough();

export const createPatientSchema = z.object({
  body: z.object({
    patientCode: z.string().optional(),
    name: z.string().min(1, 'Patient name is required'),
    email: z.string().email('Invalid email address'),
    phone: z.string().min(1, 'Phone number is required'),
    avatar: z.string().optional().default(''),
    age: z.union([z.number(), z.string().transform((v) => Number(v))]).optional().default(35),
    dateOfBirth: z.string().optional().default(''),
    gender: z.enum(['Male', 'Female', 'Other']).optional().default('Male'),
    bloodGroup: z.string().optional().default('O+'),
    bloodType: z.string().optional().default('O+'),
    address: z.string().optional().default('Hospital Ward'),
    department: z.string().optional().default('General Medicine'),
    doctor: z.string().optional().default('Dr. Alex Morgan'),
    room: z.string().optional().default('Room 101'),
    condition: z.string().optional().default('Stable'),
    admissionDate: z.string().optional(),
    emergencyContact: emergencyContactSchema.optional().default({ name: 'Next of Kin', relationship: 'Family', phone: '' }),
    medicalHistory: z.any().optional().default([]),
    allergies: z.array(z.string()).optional().default([]),
    insuranceProvider: z.string().optional().default(''),
    insurancePolicyNumber: z.string().optional().default(''),
    prescriptions: z.any().optional().default([]),
    reports: z.any().optional().default([]),
    billingInvoices: z.any().optional().default([]),
    vitals: z.any().optional(),
    status: z.string().optional().default('Admitted'),
  }).passthrough(),
});

export const updatePatientSchema = z.object({
  params: z.object({
    id: z.string().min(1, 'Patient ID is required'),
  }),
  body: z.object({
    patientCode: z.string().optional(),
    name: z.string().min(1).optional(),
    email: z.string().email().optional(),
    phone: z.string().min(1).optional(),
    avatar: z.string().optional(),
    age: z.union([z.number(), z.string().transform((v) => Number(v))]).optional(),
    dateOfBirth: z.string().optional(),
    gender: z.enum(['Male', 'Female', 'Other']).optional(),
    bloodGroup: z.string().optional(),
    bloodType: z.string().optional(),
    address: z.string().optional(),
    department: z.string().optional(),
    doctor: z.string().optional(),
    room: z.string().optional(),
    condition: z.string().optional(),
    admissionDate: z.string().optional(),
    emergencyContact: emergencyContactSchema.optional(),
    medicalHistory: z.any().optional(),
    allergies: z.array(z.string()).optional(),
    insuranceProvider: z.string().optional(),
    insurancePolicyNumber: z.string().optional(),
    prescriptions: z.any().optional(),
    reports: z.any().optional(),
    billingInvoices: z.any().optional(),
    vitals: z.any().optional(),
    status: z.string().optional(),
  }).passthrough(),
});

export const getPatientsQuerySchema = z.object({
  query: z.object({
    page: z.string().optional().transform((val) => (val ? Math.max(1, parseInt(val, 10)) : 1)),
    limit: z.string().optional().transform((val) => (val ? Math.min(100, Math.max(1, parseInt(val, 10))) : 15)),
    gender: z.enum(['Male', 'Female', 'Other']).optional(),
    bloodGroup: z.string().optional(),
    status: z.string().optional(),
    search: z.string().optional(),
  }),
});

export const patientIdParamSchema = z.object({
  params: z.object({
    id: z.string().min(1, 'Patient ID is required'),
  }),
});

export type CreatePatientInput = z.infer<typeof createPatientSchema>['body'];
export type UpdatePatientInput = z.infer<typeof updatePatientSchema>['body'];
export type GetPatientsQuery = z.infer<typeof getPatientsQuerySchema>['query'];
